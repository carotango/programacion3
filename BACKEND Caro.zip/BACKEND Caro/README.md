﻿Este pequeña aplicacion

es sobre un crud completo con los siguientes programas

node-js-with-mysql-using-sequelize-express

Es una pequeña aplicacion que hace una  busqueda de pokemones en la pagina de pokeapi 

y guardarlas en una base de datos mysql para la formacion del equipo,

se tiene que aclarar que se hace la conexion con el backend que previamente fue diseñado

El equipo lo muestro en otra página que se encuentra el enlace en la barra de menu de navegacion y este, 

esta integrado con los 5 personajes elegidos previamente 

tambien tiene enlaces a otras paginas en la barra de navegación 

Antes de usarla deben crear la base de datos pokedex_db, hacer funcionar el backend con node server.js 

y ahi se crearan automaticamente las tablas para guardar los datos




